package TASK3;

public interface Command {
    void execute(String message);
}
