package TASK3;

public enum LogLevel {
    INFO, DEBUG, ERROR
}
