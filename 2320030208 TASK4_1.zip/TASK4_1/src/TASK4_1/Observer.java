package TASK4_1;

public interface Observer {
    void update(String event);
}
